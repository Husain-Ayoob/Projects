# LanderDash
Please use the following commands to run the program

```shell
$ java -jar LanderDash.jar
```



If you need to compile the program, please use the following commands to compile and run the program

```shell
$ make clean
$ make 
$ java -jar LanderDash.jar
```
